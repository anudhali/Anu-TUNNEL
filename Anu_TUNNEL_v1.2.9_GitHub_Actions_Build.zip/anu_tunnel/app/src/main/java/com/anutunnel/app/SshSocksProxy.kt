package com.anutunnel.app

import android.util.Log
import com.jcraft.jsch.ChannelDirectTCPIP
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.EOFException
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.Proxy
import java.net.URL
import java.net.HttpURLConnection
import java.net.SocketException
import java.util.Properties
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** SSH session over the local TCP stream exposed by the DNSTT server, plus a SOCKS5 CONNECT listener. */
class SshSocksProxy {
    companion object { private const val TAG = "AnuSshProxy" }

    private val running = AtomicBoolean(false)
    private val workers: ExecutorService = Executors.newFixedThreadPool(32)
    private var session: Session? = null
    private var server: ServerSocket? = null

    fun connect(username: String, password: String, localDnsttPort: Int = 7000, socksPort: Int = 1080) {
        check(!running.get()) { "SSH proxy is already running" }
        require(username.isNotBlank() && password.isNotBlank()) { "SSH username/password is missing" }
        val jsch = JSch()
        val ssh = jsch.getSession(username, "127.0.0.1", localDnsttPort)
        ssh.setPassword(password)
        val cfg = Properties().apply {
            setProperty("StrictHostKeyChecking", "no")
            setProperty("PreferredAuthentications", "password,keyboard-interactive")
            setProperty("compression.s2c", "none")
            setProperty("compression.c2s", "none")
        }
        ssh.setConfig(cfg)
        ssh.timeout = 30_000
        ssh.setServerAliveInterval(15_000)
        ssh.setServerAliveCountMax(3)
        ssh.connect(30_000)
        check(ssh.isConnected) { "SSH authentication failed" }

        val listener = ServerSocket(socksPort, 64, InetAddress.getByName("127.0.0.1"))
        session = ssh
        server = listener
        running.set(true)
        workers.execute {
            while (running.get()) {
                try {
                    val client = listener.accept()
                    workers.execute { handleClient(client) }
                } catch (e: SocketException) {
                    if (running.get()) Log.e(TAG, "SOCKS listener stopped unexpectedly", e)
                    break
                } catch (e: Exception) {
                    if (running.get()) Log.e(TAG, "SOCKS accept error", e)
                }
            }
        }
        Log.i(TAG, "SSH authenticated through DNSTT; SOCKS5 listening on 127.0.0.1:$socksPort")
    }

    private fun handleClient(socket: Socket) {
        socket.use { client ->
            client.soTimeout = 15_000
            val input = DataInputStream(BufferedInputStream(client.getInputStream()))
            val output = BufferedOutputStream(client.getOutputStream())
            try {
                val version = input.readUnsignedByte()
                val methodCount = input.readUnsignedByte()
                if (version != 5 || methodCount !in 1..32) return
                val methods = ByteArray(methodCount)
                input.readFully(methods)
                if (methods.none { it == 0.toByte() }) {
                    output.write(byteArrayOf(5, 0xFF.toByte())); output.flush(); return
                }
                output.write(byteArrayOf(5, 0)); output.flush()

                val requestVersion = input.readUnsignedByte()
                val command = input.readUnsignedByte()
                input.readUnsignedByte() // reserved
                val addressType = input.readUnsignedByte()
                if (requestVersion != 5 || command != 1) {
                    sendReply(output, 7); return
                }
                val host = when (addressType) {
                    1 -> readExact(input, 4)
                        .joinToString(".") { (it.toInt() and 0xff).toString() }
                    3 -> {
                        val n = input.readUnsignedByte()
                        if (n == 0) throw EOFException()
                        String(readExact(input, n), Charsets.UTF_8)
                    }
                    4 -> InetAddress.getByAddress(readExact(input, 16)).hostAddress
                    else -> { sendReply(output, 8); return }
                }
                val port = input.readUnsignedShort()
                if (port == 0) { sendReply(output, 1); return }

                val ssh = session?.takeIf { it.isConnected } ?: run { sendReply(output, 1); return }
                val channel = ssh.openChannel("direct-tcpip") as ChannelDirectTCPIP
                channel.setHost(host)
                channel.setPort(port)
                channel.setOrgIPAddress("127.0.0.1")
                channel.setOrgPort(0)
                channel.connect(20_000)
                client.soTimeout = 0 // Keep established TCP streams alive during long idle periods.
                sendReply(output, 0)
                val remoteIn = channel.inputStream
                val remoteOut = channel.outputStream
                val toRemote = Thread {
                    try { client.getInputStream().copyTo(remoteOut, 16 * 1024); remoteOut.flush() }
                    catch (_: Exception) { }
                    finally { try { channel.disconnect() } catch (_: Exception) {} }
                }.apply { name = "AnuSocks-Upstream"; isDaemon = true; start() }
                try {
                    remoteIn.copyTo(output, 16 * 1024)
                    output.flush()
                } catch (_: Exception) { }
                toRemote.join(2_000)
                try { channel.disconnect() } catch (_: Exception) {}
            } catch (e: Exception) {
                Log.w(TAG, "SOCKS client closed: ${e.message}")
                try { sendReply(output, 1) } catch (_: Exception) {}
            }
        }
    }

    private fun readExact(input: DataInputStream, size: Int): ByteArray = ByteArray(size).also { input.readFully(it) }

    private fun sendReply(out: BufferedOutputStream, code: Int) {
        out.write(byteArrayOf(5, code.toByte(), 0, 1, 0, 0, 0, 0, 0, 0))
        out.flush()
    }

    /** Verify end-to-end internet access over the local SOCKS5 proxy before routing device traffic. */
    fun verifyProxy(timeoutMs: Int = 15_000): Boolean {
        var connection: HttpURLConnection? = null
        return try {
            val socks = Proxy(Proxy.Type.SOCKS, java.net.InetSocketAddress("127.0.0.1", 1080))
            connection = (URL("https://api.ipify.org").openConnection(socks) as HttpURLConnection).apply {
                connectTimeout = timeoutMs
                readTimeout = timeoutMs
                requestMethod = "GET"
                useCaches = false
                instanceFollowRedirects = false
            }
            connection.responseCode == HttpURLConnection.HTTP_OK &&
                connection.inputStream.bufferedReader().use { it.readText().trim() }.isNotEmpty()
        } catch (e: Exception) {
            Log.w(TAG, "SSH proxy verification failed: ${e.message}")
            false
        } finally {
            connection?.disconnect()
        }
    }

    fun isConnected(): Boolean = running.get() && session?.isConnected == true

    fun disconnect() {
        running.set(false)
        try { server?.close() } catch (_: Exception) {}
        server = null
        try { session?.disconnect() } catch (_: Exception) {}
        session = null
        workers.shutdownNow()
    }
}
