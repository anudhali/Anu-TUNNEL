# Anu TUNNEL v1.2.9 — Build status

## New in v1.2.9
- Added `.github/workflows/android-build.yml` to build native dependencies and the Android debug APK on an Ubuntu x86_64 GitHub Actions runner.
- Pins Go 1.24.4 and the `golang.org/x/mobile` revision used for both gomobile and gobind.
- Patches a writable temporary copy of gomobile so `gomobile init` uses the pinned gobind revision instead of `@latest`.
- Builds DNSTT AAR and Hev ARM64 JNI `.so` in CI, then builds and uploads the APK plus native artifacts and SHA256 checksums.
- Added `GITHUB_ACTIONS_BUILD.md` with the workflow steps and current feature limitations.

## Not yet verified
- The GitHub Actions workflow has been authored but has not been run from this environment. No CI success is claimed.
- No APK is included in this source ZIP until the workflow completes successfully.
- Provider DNSTT-to-SSH forwarding, SSH credentials, and a live tunnel are not verified.
- SOCKS5 UDP ASSOCIATE / UDP relay is not implemented; current bridge is TCP CONNECT only.
- Smart Auto live multi-server probing/failover is not implemented.
- BDIX routing requires a genuine Bangladesh BDIX-connected gateway; no such gateway is included.
- Physical Redmi Turbo 4 Pro / Airtel SIM testing has not been performed.

## Existing source validation
Run `python3 tools/verify_source.py` and `bash -n tools/*.sh` locally. A successful source check is not equivalent to a successful native build, APK build, or device VPN test.
