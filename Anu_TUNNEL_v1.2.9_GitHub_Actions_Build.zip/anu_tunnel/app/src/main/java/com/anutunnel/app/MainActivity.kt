package com.anutunnel.app

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.os.Build
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 6, 20)
    private val panel = Color.rgb(25, 17, 43)
    private val purple = Color.rgb(174, 55, 245)
    private val white = Color.WHITE
    private lateinit var store: ConfigStore
    private lateinit var root: LinearLayout
    private lateinit var activeContent: LinearLayout
    private var current: TunnelConfig? = null
    private var selectedMode = "Smart Auto Mode"
    private var pendingExport = ""
    private val prefs by lazy { getSharedPreferences("anu_tunnel_settings", MODE_PRIVATE) }
    private val logs by lazy { getSharedPreferences("anu_tunnel_logs", MODE_PRIVATE) }
    private val reqImport = 702
    private val reqExport = 703
    private val reqVpn = 704
    private var statusLabel: TextView? = null
    private val tunnelStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val state = intent?.getStringExtra("state") ?: return
            val detail = intent.getStringExtra("detail") ?: ""
            statusLabel?.text = "● $state\n$detail"
            statusLabel?.setTextColor(when (state) { "CONNECTED" -> Color.rgb(70, 230, 140); "ERROR" -> Color.RED; else -> Color.LTGRAY })
            addLog("$state: $detail")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ConfigStore(this)
        if (store.all().isEmpty()) {
            val initial = TunnelConfig()
            store.upsert(initial)
            store.select(initial.id)
        }
        current = store.all().firstOrNull { it.id == store.selectedId() } ?: store.all().firstOrNull()
        selectedMode = prefs.getString("mode", "Smart Auto Mode") ?: "Smart Auto Mode"
        if (selectedMode == "BDIX Mode") {
            selectedMode = "Global Mode"
            prefs.edit().putString("mode", selectedMode).apply()
        }
        showHome()
    }

    private fun base(title: String): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(16, 12, 16, 12)
        }
        val header = TextView(this).apply {
            text = title
            textSize = 24f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(4, 10, 4, 18)
        }
        root.addView(header)
        val scroll = ScrollView(this)
        activeContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 16)
        }
        scroll.addView(activeContent)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        return activeContent
    }

    private fun label(text: String, size: Float = 15f): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(white)
        setPadding(4, 7, 4, 7)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(14, 12, 14, 12)
        setBackgroundColor(panel)
    }

    private fun addCard(view: View) {
        activeContent.addView(view, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
    }

    private fun button(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        setTextColor(white)
        setBackgroundColor(purple)
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun field(title: String, value: String, hint: String = ""): Pair<LinearLayout, EditText> {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(label(title, 13f))
        val edit = EditText(this).apply {
            setText(value)
            setTextColor(white)
            setHintTextColor(Color.LTGRAY)
            setHint(hint)
            textSize = 15f
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.rgb(12, 9, 23))
        }
        box.addView(edit, LinearLayout.LayoutParams(-1, -2))
        return box to edit
    }

    private fun showHome() {
        val c = base("Anu TUNNEL  ✦")
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.anu_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Anu TUNNEL logo"
        }
        c.addView(logo, LinearLayout.LayoutParams(-1, 205))
        c.addView(label("SSH • DNSTT  |  Premium Tunnel", 15f))
        val statePrefs = getSharedPreferences("anu_tunnel_state", MODE_PRIVATE)
        statusLabel = label("● ${statePrefs.getString("state", "DISCONNECTED")}\n${statePrefs.getString("detail", "Ready")}", 16f).apply { setTextColor(Color.LTGRAY) }
        c.addView(statusLabel)

        val cfg = current ?: store.all().firstOrNull()
        val summary = card()
        summary.addView(label("ACTIVE CONFIG", 12f))
        summary.addView(label(cfg?.name ?: "No configuration", 19f))
        summary.addView(label(cfg?.let { "${it.connectionType}\nAccount: ${it.account.substringBefore(":")}:••••••\nDNS: ${it.udpDns}\nSNI: ${it.serverName}" } ?: "Create a configuration first", 13f))
        addCard(summary)

        val modes = card()
        modes.addView(label("NETWORK MODE", 16f))
        listOf("🌍 Global Mode", "⚡ Smart Auto Mode").forEach { item ->
            val mode = if (item.contains("Global")) "Global Mode" else "Smart Auto Mode"
            modes.addView(button(item + if (selectedMode == mode) "  ✓" else "") {
                selectedMode = mode
                prefs.edit().putString("mode", mode).apply()
                addLog("Mode selected: $mode")
                showHome()
            })
        }
        addCard(modes)

        c.addView(button("CONNECT") { connectNotice() })
        c.addView(button("DISCONNECT") {
            startService(Intent(this, AnuVpnService::class.java).setAction(AnuVpnService.ACTION_DISCONNECT))
            toast("Disconnect requested")
        })
        c.addView(button("Config Manager / New / Reset / Import / Export") { showConfigManager() })
        c.addView(button("Tools: Speed Test / DNS / IP / Network") { showTools() })
        c.addView(button("Split Tunneling") { showSplitTunneling() })
        c.addView(button("Logs") { showLogs() })
        c.addView(button("Settings") { showSettings() })
        c.addView(label("Selected mode: $selectedMode\nSmart Auto currently uses the selected profile; automatic multi-server probing requires additional server profiles and is not yet enabled.", 12f))
    }

    private fun connectNotice() {
        val config = current ?: store.all().firstOrNull()
        if (config == null) { toast("Create a configuration first"); return }
        val credentials = config.account.split(":", limit = 2)
        if (credentials.size != 2 || credentials[0].isBlank() || credentials[1].isBlank()) {
            toast("Account format must be SSH_USERNAME:SSH_PASSWORD")
            return
        }
        val permissionIntent = VpnService.prepare(this)
        if (permissionIntent != null) startActivityForResult(permissionIntent, reqVpn)
        else startVpnService(config, credentials[0], credentials[1])
    }

    private fun startVpnService(config: TunnelConfig, username: String, password: String) {
        val intent = Intent(this, AnuVpnService::class.java).setAction(AnuVpnService.ACTION_CONNECT)
            .putExtra("dns", config.udpDns)
            .putExtra("domain", config.serverName)
            .putExtra("public_key", config.publicKey)
            .putExtra("ssh_username", username)
            .putExtra("ssh_password", password)
            .putExtra("network_mode", selectedMode)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        toast("Anu TUNNEL connection started")
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter(AnuVpnService.ACTION_STATE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(tunnelStateReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(tunnelStateReceiver, filter)
        val statePrefs = getSharedPreferences("anu_tunnel_state", MODE_PRIVATE)
        statusLabel?.text = "● ${statePrefs.getString("state", "DISCONNECTED")}\n${statePrefs.getString("detail", "Ready")}"
    }

    override fun onPause() {
        try { unregisterReceiver(tunnelStateReceiver) } catch (_: Exception) {}
        super.onPause()
    }

    private fun showConfigManager() {
        val c = base("Config Manager")
        c.addView(button("＋ New Config") {
            current = TunnelConfig(name = "New Config")
            showEditor(current!!)
        })
        c.addView(button("Import JSON") { pickImport() })
        c.addView(button("Export All JSON") { exportText(store.exportJson(), "anu-tunnel-configs.json") })
        c.addView(button("Reset All Configs") {
            AlertDialog.Builder(this).setTitle("Reset all configs?")
                .setMessage("All saved configurations will be removed and the starter profile will be restored.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Reset") { _, _ ->
                    store.reset()
                    val starter = TunnelConfig()
                    store.upsert(starter)
                    store.select(starter.id)
                    current = starter
                    addLog("All configurations reset")
                    showConfigManager()
                }.show()
        })
        store.all().forEach { config ->
            val item = card()
            item.addView(label(config.name + if (config.id == current?.id) "  ✓ ACTIVE" else "", 18f))
            val safeAccount = config.account.substringBefore(":") + if (":" in config.account) ":••••••" else ""
            item.addView(label("${config.connectionType}\n$safeAccount\nDNS: ${config.udpDns}\nSNI: ${config.serverName}", 13f))
            item.addView(button("Use this config") {
                current = config
                store.select(config.id)
                addLog("Selected config: ${config.name}")
                toast("Selected: ${config.name}")
                showHome()
            })
            item.addView(button("Edit") { showEditor(config) })
            item.addView(button("Export this config") { exportText(store.exportJson(listOf(config)), safeFileName(config.name) + ".json") })
            item.addView(button("Delete") {
                AlertDialog.Builder(this).setMessage("Delete ${config.name}?")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete") { _, _ ->
                        store.delete(config.id)
                        if (current?.id == config.id) current = store.all().firstOrNull()
                        if (store.all().isEmpty()) {
                            val starter = TunnelConfig()
                            store.upsert(starter)
                            current = starter
                        }
                        current?.let { store.select(it.id) }
                        addLog("Deleted config: ${config.name}")
                        showConfigManager()
                    }.show()
            })
            addCard(item)
        }
        c.addView(button("← Home") { showHome() })
    }

    private fun showEditor(config: TunnelConfig) {
        val c = base("Config Input")
        val fields = mutableMapOf<String, EditText>()
        fun add(key: String, title: String, value: String, hint: String = "") {
            val pair = field(title, value, hint)
            c.addView(pair.first)
            fields[key] = pair.second
        }
        add("name", "Config Name", config.name)
        add("account", "SSH Account (Username:Password)", config.account)
        add("dns", "UDP DNS (IP:Port)", config.udpDns, "8.8.8.8:53")
        add("sni", "Server Name (SNI / Tunnel domain)", config.serverName)
        add("key", "Public Key", config.publicKey)
        add("payload", "Payload (Optional)", config.payload)
        val dnsOnly = CheckBox(this).apply {
            text = "Use DNS Tunneling Only (DNSTT)"
            setTextColor(white)
            isChecked = config.dnsOnly
        }
        c.addView(dnsOnly)
        val makeDefault = CheckBox(this).apply {
            text = "Save as Default Config"
            setTextColor(white)
            isChecked = config.isDefault
        }
        c.addView(makeDefault)

        c.addView(button("Save Config") {
            val name = fields["name"]!!.text.toString().trim()
            val account = fields["account"]!!.text.toString().trim()
            val dns = fields["dns"]!!.text.toString().trim()
            val sni = fields["sni"]!!.text.toString().trim()
            val key = fields["key"]!!.text.toString().trim()
            val dnsParts = dns.split(":")
            val port = dnsParts.getOrNull(1)?.toIntOrNull()
            val ipValid = dnsParts.size == 2 && dnsParts[0].matches(Regex("^(\\d{1,3}\\.){3}\\d{1,3}$")) &&
                dnsParts[0].split(".").all { part -> part.toIntOrNull()?.let { value -> value in 0..255 } == true }
            if (name.isBlank() || account.isBlank() || dns.isBlank() || sni.isBlank() || key.isBlank()) {
                toast("Required fields are missing")
                return@button
            }
            if (!ipValid || port == null || port !in 1..65535) {
                toast("DNS must be a valid IPv4:Port, e.g. 8.8.8.8:53")
                return@button
            }
            if (!key.matches(Regex("^[0-9a-fA-F]{64}$"))) {
                toast("DNSTT public key must be 64 hexadecimal characters")
                return@button
            }
            config.name = name
            config.account = account
            config.udpDns = dns
            config.serverName = sni
            config.publicKey = key
            config.payload = fields["payload"]!!.text.toString()
            config.dnsOnly = dnsOnly.isChecked
            config.isDefault = makeDefault.isChecked
            if (config.isDefault) {
                val others = store.all().onEach { other ->
                    if (other.id != config.id) other.isDefault = false
                }
                store.save(others)
            }
            store.upsert(config)
            current = config
            store.select(config.id)
            addLog("Saved config: ${config.name}")
            toast("Configuration saved")
            showConfigManager()
        })
        c.addView(button("Reset Fields") { showEditor(TunnelConfig(id = config.id)) })
        c.addView(button("Cancel") { showConfigManager() })
    }

    private fun pickImport() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).setType("application/json")
            .addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(intent, reqImport)
    }

    private fun exportText(text: String, name: String) {
        pendingExport = text
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json")
            .putExtra(Intent.EXTRA_TITLE, name)
        startActivityForResult(intent, reqExport)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqVpn) {
            if (resultCode == RESULT_OK) {
                try {
                    val config = current ?: store.all().firstOrNull() ?: error("No configuration selected")
                    val credentials = config.account.split(":", limit = 2)
                    if (credentials.size != 2 || credentials.any { it.isBlank() }) error("Account format must be SSH_USERNAME:SSH_PASSWORD")
                    startVpnService(config, credentials[0], credentials[1])
                } catch (error: Exception) { toast(error.message ?: "VPN permission failed") }
            } else toast("VPN permission was not granted")
            return
        }
        if (resultCode != RESULT_OK || data?.data == null) return
        try {
            when (requestCode) {
                reqImport -> {
                    val raw = contentResolver.openInputStream(data.data!!)?.bufferedReader()?.use { it.readText() }
                        ?: throw IllegalStateException("Cannot read selected file")
                    val count = store.importJson(raw)
                    current = store.all().firstOrNull { it.id == store.selectedId() } ?: store.all().firstOrNull()
                    addLog("Imported $count config(s)")
                    toast("Imported $count config(s)")
                    showConfigManager()
                }
                reqExport -> {
                    contentResolver.openOutputStream(data.data!!)?.bufferedWriter()?.use { it.write(pendingExport) }
                        ?: throw IllegalStateException("Cannot write selected file")
                    addLog("Configuration export completed")
                    toast("Export completed")
                }
            }
        } catch (error: Exception) {
            toast("File operation failed: ${error.message ?: "Unknown error"}")
        }
    }

    private fun showTools() {
        val c = base("Tools")
        val result = label("Ready", 16f)
        c.addView(result)
        c.addView(button("DNS Lookup Test") {
            result.text = "Testing DNS lookup..."
            thread {
                val start = System.nanoTime()
                val message = try {
                    InetAddress.getByName("dns.google")
                    "DNS lookup completed in ${(System.nanoTime() - start) / 1_000_000} ms (not an internet speed test)"
                } catch (error: Exception) { "DNS lookup failed: ${error.message}" }
                runOnUiThread { result.text = message; addLog(message) }
            }
        })
        c.addView(button("Network Info") {
            val manager = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = manager.activeNetwork
            val caps = manager.getNetworkCapabilities(network)
            result.text = if (caps == null) "No active network" else buildString {
                append("Network connected\n")
                append("Wi-Fi: ${caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)}\n")
                append("Cellular: ${caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)}\n")
                append("Ethernet: ${caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)}\n")
                append("Validated internet: ${caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)}")
            }
        })
        c.addView(button("Real Download Speed Test (10 MB)") {
            AlertDialog.Builder(this).setTitle("Use about 10 MB of data?")
                .setMessage("This test downloads a 10 MB test file from Cloudflare. Your carrier may charge data fees.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Start") { _, _ -> runSpeedTest(result) }.show()
        })
        c.addView(button("Public IP Checker") {
            result.text = "Checking public IP..."
            thread {
                val message = try {
                    val connection = (URL("https://api.ipify.org").openConnection() as HttpURLConnection).apply {
                        connectTimeout = 8000; readTimeout = 8000; requestMethod = "GET"
                    }
                    val ip = connection.inputStream.bufferedReader().use { it.readText().trim() }
                    connection.disconnect()
                    "Public IP: $ip"
                } catch (error: Exception) { "IP lookup failed: ${error.message}" }
                runOnUiThread { result.text = message; addLog(message) }
            }
        })
        c.addView(button("← Home") { showHome() })
    }

    private fun runSpeedTest(output: TextView) {
        output.text = "Downloading test data..."
        thread {
            val started = System.nanoTime()
            val message = try {
                val connection = (URL("https://speed.cloudflare.com/__down?bytes=10000000").openConnection() as HttpURLConnection).apply {
                    connectTimeout = 12000; readTimeout = 20000; requestMethod = "GET"
                }
                var bytes = 0L
                val buffer = ByteArray(32 * 1024)
                connection.inputStream.use { stream ->
                    while (true) {
                        val count = stream.read(buffer)
                        if (count < 0) break
                        bytes += count
                    }
                }
                connection.disconnect()
                val seconds = ((System.nanoTime() - started) / 1_000_000_000.0).coerceAtLeast(0.001)
                val mbps = (bytes * 8.0 / seconds) / 1_000_000.0
                "Measured download: ${String.format(Locale.US, "%.2f", mbps)} Mbps\nData: ${bytes / 1_000_000.0} MB | Time: ${String.format(Locale.US, "%.2f", seconds)} s"
            } catch (error: Exception) { "Speed test failed: ${error.message}" }
            runOnUiThread { output.text = message; addLog(message) }
        }
    }

    private fun showSplitTunneling() {
        val c = base("Split Tunneling")
        c.addView(label("Select apps to exclude from the future VPN route. These choices are saved now; routing takes effect only after the VPN packet engine is integrated.", 13f))
        val selected = prefs.getStringSet("split_excluded", emptySet<String>())?.toMutableSet() ?: mutableSetOf()
        val apps = packageManager.getInstalledApplications(0).sortedBy { packageManager.getApplicationLabel(it).toString().lowercase(Locale.ROOT) }
        apps.forEach { app ->
            val name = packageManager.getApplicationLabel(app).toString()
            val check = CheckBox(this).apply {
                text = name
                setTextColor(white)
                isChecked = app.packageName in selected
                setOnCheckedChangeListener { _, checked ->
                    if (checked) selected.add(app.packageName) else selected.remove(app.packageName)
                    prefs.edit().putStringSet("split_excluded", selected.toSet()).apply()
                }
            }
            c.addView(check)
        }
        c.addView(button("← Home") { showHome() })
    }

    private fun showLogs() {
        val c = base("Connection Logs")
        val entries = logs.getString("entries", "") ?: ""
        c.addView(label(if (entries.isBlank()) "No logs yet" else entries, 12f))
        c.addView(button("Clear Logs") {
            logs.edit().remove("entries").apply()
            addLog("Logs cleared")
            showLogs()
        })
        c.addView(button("← Home") { showHome() })
    }

    private fun showSettings() {
        val c = base("Settings")
        c.addView(label("Anu TUNNEL v1.2.2\nDNSTT → SSH → SOCKS5 → TUN packet forwarding\nCredentials are stored in the local profile; do not share exported config files containing passwords."))
        addSettingSwitch(c, "Auto Reconnect", "auto_reconnect", false)
        addSettingSwitch(c, "Keep Alive", "keep_alive", true)
        addSettingSwitch(c, "Show Connection Log", "show_logs", true)
        addSettingSwitch(c, "Dark Theme", "dark_theme", true)
        c.addView(button("Clear Logs") {
            logs.edit().remove("entries").apply()
            toast("Logs cleared")
        })
        c.addView(button("About Anu TUNNEL") {
            AlertDialog.Builder(this).setTitle("Anu TUNNEL v1.2.2")
                .setMessage("SSH • DNSTT\nThis build integrates the DNSTT Go client, SSH-over-DNSTT authentication, and hev tun2socks packet forwarding. A successful connection still requires a valid provider account and a DNSTT server configured to forward to its SSH service.")
                .setPositiveButton("OK", null).show()
        })
        c.addView(button("← Home") { showHome() })
    }

    private fun addSettingSwitch(container: LinearLayout, title: String, key: String, default: Boolean) {
        val toggle = Switch(this).apply {
            text = title
            setTextColor(white)
            isChecked = prefs.getBoolean(key, default)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
        }
        container.addView(toggle)
    }

    private fun addLog(message: String) {
        if (!prefs.getBoolean("show_logs", true)) return
        val old = logs.getString("entries", "") ?: ""
        val line = "[${java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(java.util.Date())}] $message"
        val updated = (listOf(line) + old.lines().filter { it.isNotBlank() }).take(200).joinToString("\n")
        logs.edit().putString("entries", updated).apply()
    }

    private fun safeFileName(value: String) = value.replace(Regex("[^A-Za-z0-9_-]"), "_").take(48).ifBlank { "anu-config" }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
