# Anu TUNNEL — Android Kotlin project

**Package:** `com.anutunnel.app`  
**Version:** `1.2.2`  
**Target:** Android API 24+; arm64-v8a native engine; AndroidIDE/JDK 17; target SDK 35.

## Integrated tunnel architecture

```text
Android apps
  -> Android VpnService TUN descriptor
  -> hev-socks5-tunnel (tun2socks JNI)
  -> local SOCKS5 TCP CONNECT listener (127.0.0.1:1080)
  -> SSH direct-tcpip channels (JSch)
  -> SSH session to 127.0.0.1:7000
  -> DNSTT Go client local TCP endpoint
  -> DNS resolver (for example 8.8.8.8:53)
  -> provider DNSTT server / its configured SSH forward
```

## Native dependencies and reproducible build

`tools/build_native.sh` builds two native dependencies for the phone's `arm64-v8a` ABI:

1. Clones the official `dnstt-xyz/dnstt_xyz_app` repository (sparse checkout of `go_src`), copies in `tools/native/dnsttbridge/bridge.go`, installs the pinned `gomobile`/`gobind` version without invoking `gomobile init` (which auto-installs unpinned `gobind@latest`), and runs `gomobile bind` to create `app/libs/dnstt.aar`. The wrapper intentionally exposes only gomobile-compatible methods; it does not bind upstream callback or raw `net.Conn` APIs.
2. Clones `heiher/hev-socks5-tunnel` with submodules and runs Android NDK `ndk-build`, placing `libhev-socks5-tunnel.so` in `app/src/main/jniLibs/arm64-v8a/`.

Requirements: Git, Go with toolchain auto-download/network access, Java/JDK 17, Android SDK Platform 35, and Android NDK. The DNSTT upstream module declares Go 1.24.0; `GOTOOLCHAIN=auto` is enabled in the build script. Set `ANDROID_NDK_HOME` to the installed NDK directory if auto-detection does not find it. `Application.mk` enables flexible 16 KB page-size support for newer Android devices.

## Build in AndroidIDE

1. Extract the ZIP and open the `anu_tunnel` project folder in AndroidIDE.
2. Select JDK 17 and install Android SDK Platform 35+ and an NDK.
3. Run `bash tools/check_environment.sh` to check the local build tools.
4. Run `bash tools/build_native.sh` once, or let Gradle run it automatically during `:app:assembleDebug`.
5. Build the `:app:assembleDebug` task from AndroidIDE. If using a terminal, run `./gradlew assembleDebug` when Gradle is available on PATH. A wrapper JAR is not bundled in this source milestone.

Native source is fetched from official upstream repositories during the build rather than copied into this ZIP. This keeps upstream source and licenses intact and avoids shipping unverified binary blobs.

## SSH account format and provider requirements

The `Account` field is parsed as:

```text
SSH_USERNAME:SSH_PASSWORD
```

Enter your SSH credentials on the device; they are intentionally not prefilled in the project. The app connects its SSH client to `127.0.0.1:7000`, the local TCP endpoint created by DNSTT. Therefore the provider-side DNSTT server must forward its incoming stream to the provider's SSH service (normally TCP port 22). The `Server Name` field is the DNSTT tunnel domain, not necessarily the SSH hostname. A DNS tunnel domain/public key by itself does not supply SSH credentials or guarantee the server's forwarding target.

Profile data is stored locally. Exported JSON contains credentials if they are saved in a profile; do not share exported config files. Local profile storage is not encrypted in this revision.

## Functional scope and important limitations

- The source integrates the DNSTT Go client bridge, SSH password authentication, a local SOCKS5 TCP CONNECT proxy, Android `VpnService`, and the upstream Hev TUN-to-SOCKS5 JNI interface.
- The SOCKS5 bridge currently handles TCP CONNECT only. UDP ASSOCIATE is not implemented, so arbitrary UDP applications, QUIC/HTTP/3, games and some voice/video traffic are not guaranteed to work. The Hev config's UDP relay mode cannot overcome the missing UDP relay implementation in the SSH proxy.
- The DNSTT/SSH chain only works if the provider's DNSTT server is configured to forward to its SSH service. A successful local DNSTT start alone does not prove SSH authentication or internet access. The app verifies an HTTPS request through the local SOCKS5 proxy before bringing up packet forwarding.
- BDIX mode has been removed from this build at the user’s request.
- Global mode uses the selected provider profile. Smart Auto currently falls back to the selected profile and reports that multi-server latency/failover is not configured; it is not yet an automatic multi-server selector.
- Split-tunnel app exclusions are applied to the Android VPN builder when the VPN is established.
- The speed test is a separate direct HTTPS download; it is not a VPN throughput guarantee.

## Validation status

Source-level integration assertions, shell syntax checks, Python verifier syntax and Android XML parsing pass. This delivery environment has no Android SDK/NDK and its installed Go is 1.23.2; upstream DNSTT requires Go 1.24+. The script enables Go's automatic toolchain download, but the native AAR/shared library, Gradle APK, and on-device connection have **not** been built or tested here. This ZIP is an integration source milestone, not a verified installable APK.

Before release, build on AndroidIDE with network access, Go toolchain auto-download, NDK and SDK, then test DNSTT handshake, SSH authentication, DNS leak behavior, TUN forwarding, IPv4/IPv6, network handover, Android 17 lifecycle, UDP-dependent apps, disconnect cleanup and real throughput.

## AndroidIDE terminal environment fix (v1.2.3)

This project includes `tools/androidide_env.sh`. It resolves AndroidIDE's JDK 17 under `/opt/java`, SDK under `/opt/android_sdk`, and an installed NDK by locating `ndk-build`. Both `tools/check_environment.sh` and `tools/build_native.sh` source this helper, so the terminal's inherited Java 8 PATH no longer silently overrides the configured JDK 17. `./gradlew` also sources the helper before selecting the wrapper or system Gradle.

After extracting the project, run:

```bash
bash tools/check_environment.sh
bash tools/build_native.sh
./gradlew assembleDebug
```

If the NDK installation is not complete, wait for AndroidIDE to finish downloading NDK r27d, then reopen the terminal and rerun the preflight. If Gradle is not exposed on terminal PATH, run the `:app:assembleDebug` task from AndroidIDE's Gradle task UI. This helper does not fabricate missing SDK/NDK/Gradle components; it reports them.

## v1.2.9 cloud build option

AndroidIDE on ARM64 may not be able to execute gomobile's host-side toolchain. This source package therefore includes `.github/workflows/android-build.yml`. Follow `GITHUB_ACTIONS_BUILD.md` to build the DNSTT AAR, Hev ARM64 JNI library, and debug APK on GitHub Actions. The workflow has not been executed from this packaging environment; wait for a successful Actions run before installing an APK.
