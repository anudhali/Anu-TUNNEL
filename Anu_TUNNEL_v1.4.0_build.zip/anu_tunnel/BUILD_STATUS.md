# Anu TUNNEL v1.3.0 — implementation status

## Implemented in source
- Global Mode and Smart Auto Mode only; BDIX is removed.
- DNSTT Go native client bridge, SSH password authentication, SOCKS5 TCP CONNECT, Android VpnService and Hev TUN-to-SOCKS packet forwarding.
- Multiple local profiles with create/edit/save/delete/select/default/reset and JSON import/export.
- Saved SSH credentials are encrypted at rest using an Android Keystore AES-GCM key. Legacy plaintext profile values are migrated on the next save. JSON exports intentionally contain credentials and must be kept private.
- SSH server host key trust-on-first-use pinning per DNSTT profile; later key changes are rejected.
- Smart Auto tests each configured UDP DNS resolver with a real DNS query and selects the lowest-latency responding resolver. This is resolver selection, not full SSH endpoint failover.
- Auto Reconnect monitors default-network loss/restoration and retries failed connection attempts when enabled.
- Split-tunnel exclusions are applied through Android VpnService when the tunnel is established.
- Live upload/download throughput counters are measured from actual SOCKS TCP streams; ping is TCP connect latency to 1.1.1.1:443 through the SOCKS/SSH/DNSTT path.
- Speed test and public IP lookup use the local SOCKS proxy while the VPN is connected; otherwise they use the direct network.
- Connection state and logs are exposed in the app UI.

## Known limitations (not represented as complete)
- SOCKS5 supports TCP CONNECT only. UDP ASSOCIATE and a UDP relay are not implemented. DNSTT's stream transport plus the current SSH direct-tcpip bridge cannot carry arbitrary UDP. A compatible UDP relay and provider-side forwarding endpoint are required.
- Smart Auto chooses the fastest responding configured DNS resolver; it does not yet attempt a complete DNSTT+SSH handshake against every profile and fail over between SSH servers.
- Host key pinning is trust-on-first-use: the first key is pinned after the initial SSH handshake; subsequent changes are rejected. Users should verify the provider's fingerprint independently when available.
- Split tunneling depends on Android package visibility and OS VPN behavior. Test each target app on-device.
- A successful GitHub build proves compilation and artifact packaging only. Provider-side DNSTT-to-SSH forwarding, credentials, real mobile-network connectivity, data throughput and Android device lifecycle still require physical-device testing.

## Validation
Run `python3 tools/verify_source.py` and `bash -n tools/*.sh`. These checks are source-level validation, not a substitute for GitHub Actions build or real-device tests.
